public class ObjectCode {
//    create the object toolkit for the rest of the class

    public final int EMPTY_CODE = 0;
    public final int STARS_CODE = 1;
    public final int SUN_CODE = 2;

    public final int MAX_DRONES = 10;
    public final int OK_CODE = 1;
    public final int CRASH_CODE = -1;
    public ObjectCode(){

    }

}
